<?php 

if(isset($_POST['contact_submit'])){
    
$name = $_POST['name'];

$email = $_POST['email'];

$phone = $_POST['phone'];

$city = $_POST['city'];

$destination = $_POST['destination'];
    
require 'PHPMailer/PHPMailerAutoload.php';

$mail = new PHPMailer;

$mail->isSMTP();

$mail->Host = 'smtp.hostinger.com';

$mail->Port = 587;

$mail->SMTPAuth = true;

$mail->Username = 'no-reply@viahimalaya.in';

$mail->Password = 'HhT#2k23';

$mail->setFrom('no-reply@viahimalaya.in', 'Via Himalaya');

$mail->addReplyTo('info@viahimalaya.in', 'Via Himalaya');

$mail->addAddress('info@viahimalaya.in', 'Via Himalaya'); 

$mail->addCC('rm18843@gmail.com', 'Via Himalaya'); 

$mail->Subject = 'Himachal Hill Tours Enquiry';

$body = "<html><body style='font-family: Arial, sans-serif;font-size:14px;line-height:18px;color:#000000'>";

$body .= "<p><b>Booking Detail From Website  - Via Himalaya GT - Spiti</b></p>\r\n";

$body .= "<p>Name: $name<br>Email: $email<br>Phone: $phone<br>City: $city<br>Destination: $destination</p>\r\n";

$body .= "</body></html>";

$mail->msgHTML($body);

if (!$mail->send()) {

echo 'Mailer Error: ' . $mail->ErrorInfo;

} else {
    
header('location:thanks.html');
  
}


} 

?>