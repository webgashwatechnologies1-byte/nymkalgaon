<?php
$ch = curl_init("https://google.com");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$data = curl_exec($ch);

if(curl_errno($ch)){
    echo curl_error($ch);
}else{
    echo "CURL OK";
}
curl_close($ch);
