<?php

// Check if form is submitted
if (isset($_POST['contact_submit'])) {
    
    // Retrieve form data
    $name = urlencode(trim($_POST['name']));
    $email = urlencode(trim($_POST['email']));
    $phone = urlencode(trim($_POST['phone']));
    $city = urlencode(trim($_POST['city']));
    $pageID = "Himachal-page";

    // Initialize cURL
    $name = urlencode(trim($_POST['name']));
    $email = urlencode(trim($_POST['email']));
    $phone = urlencode(trim($_POST['phone']));
    $city = urlencode(trim($_POST['city']));
    $pageID = "Himachal-page";

    // Initialize cURL
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://crm.yaaranaholidays.com/WebService.asmx/newQuery?Name=' . $name . '&Email=' . $email . '&Phone=' . $phone . '&City=' . $city . '&pageID=Himachal%20Landing-2',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 2, // Shortened timeout for faster response
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'apiKey: re456gergjlrg$jrt44'
        ),
    ));

    // Execute the cURL request in the background
    curl_exec($curl);
    curl_close($curl);

    // Prepare email sending
    require 'PHPMailer/PHPMailerAutoload.php';
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->Username = 'no-reply@yaaranaholiday.com';
    $mail->Password = 'HhT#2k23';
    $mail->setFrom('no-reply@yaaranaholiday.com', 'Yaarana Holiday');
    $mail->addReplyTo('no-reply@yaaranaholiday.com', 'Yaarana Holiday');
    $mail->addAddress('no-reply@yaaranaholiday.com', 'Yaarana Holiday'); 
    $mail->Subject = 'Yaarana Holiday Enquiry';

    $body = "<html><body style='font-family: Arial, sans-serif;font-size:14px;line-height:18px;color:#000000'>";
    $body .= "<p><b>Booking Detail From Website - Yaarana Holiday GT </b></p>\r\n";
    $body .= "<p>Name: $name<br>Email: $email<br>Phone: $phone<br>City: $city</p>\r\n";
    $body .= "</body></html>";
    
    $mail->msgHTML($body);
    
    // Start sending the email but do not wait for it to complete
    $mail->send(); // Ignoring return value for faster execution

    // Redirect immediately
    header('Location: thanks.html');  
    exit();
}
?>
